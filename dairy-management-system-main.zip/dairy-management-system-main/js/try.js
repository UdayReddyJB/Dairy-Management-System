sum=function(){
	var i,
	n=arguments.length,
	total=0;
	for ( i = 0; i<=n; i++) {
		total+=arguments[i]; 
		
	}
	return total;
	
}