<?php
header("Location: rates/new.php",TRUE,302);
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
