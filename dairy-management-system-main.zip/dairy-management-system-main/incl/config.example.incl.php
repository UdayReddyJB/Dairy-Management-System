<?php
define('db_host', 'localhost');
define('db_user', 'root');
define('db_password', '');
define('db_database', 'dairy');
define ('PAGE_URL', 'http://localhost/dairy/');

